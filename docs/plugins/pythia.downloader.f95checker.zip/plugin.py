"""
f95checker downloader plugin -- launches f95checker as its own window. Watching for
new files afterward is the caller's job (Pythia's own download manager watches
whatever folder it's tracking, the same way regardless of which downloader plugin
was used to launch the tool) -- this plugin's job stops at "start it and hand back
the process handle." StdoutWatcher-based progress parsing stays unimplemented
(f95checker's real CLI output format hasn't been inspected -- see the Milestone 2
plan's deferral).
"""

import subprocess

from pythia.plugins import DownloaderPlugin


class F95CheckerDownloaderPlugin(DownloaderPlugin):
    id = "pythia.downloader.f95checker"
    display_name = "F95Checker"
    version = "1.0.0"
    author = "pythia"
    platforms = ["windows", "linux"]
    # Not tied to any storefront library kind -- it tracks/downloads updates for
    # adult VN/RPGM/Unity titles regardless of how they were originally onboarded
    # (most of this user's library is "unknown"/generic or "renpy").
    compatible_library_kinds = ["*"]

    def launch(self, context: dict):
        """context: {"executable_path": str (defaults to "f95checker" on PATH)}."""
        executable = context.get("executable_path") or "f95checker"
        return subprocess.Popen([executable])


PLUGIN_CLASSES = [F95CheckerDownloaderPlugin]
