"""
Epic Games Store library plugin.

1. `match()`/`is_root()` -- local-install detection via Epic's own manifest
   directory, `C:\\ProgramData\\Epic\\EpicGamesLauncher\\Data\\Manifests\\*.item`
   (real location, confirmed in Lutris's `util/egs/egs_launcher.py` -- it reads the
   same directory under a Wine prefix, since Lutris runs on Linux; on Windows it's
   just the real Program Data path directly, no prefix involved). Each `.item` file
   is JSON; Lutris's own code only ever reads `AppName`/`MainGameAppName` from it
   (confirmed), cross-referencing everything else against its already-synced online
   library data. This plugin follows the same shape: `AppName` is the one field
   trusted from the manifest; `DisplayName`/`InstallLocation` are read defensively.

2. `list_owned()` -- real account-level ownership, delegated to `legendary`
   (github.com/derrod/legendary, GPLv3) as a **downloaded standalone binary, shelled
   out to via subprocess** -- not a Python import (2026-08-03, second correction:
   "we can make it an optional dependency or downloadable dependency. Like the
   runners system"). The standalone `pythia.exe` build has no pip/Python environment
   a user could install `legendary-gl` into at runtime, so a `pip install`-based
   optional dependency only ever worked for the `python -m pythia` source-checkout
   path. This plugin downloads the real, official, architecture-matched prebuilt
   binary itself (2026-08-07, "Plugins need to be completely self-contained ...
   steamcmd should provide the steamcmd tool" -- extended the same way to legendary
   here: no `pythia.core.runners` dependency, this plugin's own `_ensure_legendary()`
   below does the same download+extract with stdlib only, confirmed against
   legendary's actual GitHub release assets -- x86_64 Windows/Linux only, no arm64
   build exists, so this correctly reports "not available" on arm64 rather than
   downloading a mismatched binary) into `self.data_dir()`, and runs it as a
   subprocess -- the same external-tool-binary model Lutris's own runners system
   uses for Wine/Proton, not an in-process Python import.

   legendary keeps its own local session file inside `self.data_dir()` (local, NOT
   the synced `datadir/`) via the `LEGENDARY_CONFIG_PATH` env var passed to the
   subprocess -- syncing it directly would let two systems both write the same
   file, violating the single-writer-per-file rule everything else in datadir/
   depends on. This doesn't lose the "log in once" benefit: the session itself
   doesn't need to sync, because `list_owned()`'s *output* already flows through
   `onboarding.sync_owned()` into the already-synced `datadir/*.json` -- a user
   only needs to run `epic-connect`/`epic-token` on one system, ever.

   The OAuth login itself still uses Epic's own official redirect flow (a plain
   browser tab + copy-pasted JSON, no embedded browser) -- unchanged.
"""

import json
import os
import platform
import subprocess
import sys
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

from pythia.plugins import LibraryPlugin, ManagerPlugin

_MANIFESTS_DIR = Path(r"C:\ProgramData\Epic\EpicGamesLauncher\Data\Manifests")

# legendary's real, official GitHub release assets (confirmed 2026-08-03) -- no
# arm64 build published, so arm64 machines correctly get no binary rather than a
# mismatched-architecture guess.
_LEGENDARY_RELEASE = {
    ("Windows", "x86_64"): "https://github.com/legendary-gl/legendary/releases/download/0.20.34/legendary.exe",
    ("Linux", "x86_64"): "https://github.com/legendary-gl/legendary/releases/download/0.20.34/legendary",
}


def _normalized_arch() -> str:
    machine = platform.machine().lower()
    if machine in ("amd64", "x86_64"):
        return "x86_64"
    if machine in ("arm64", "aarch64"):
        return "arm64"
    return machine


class EgsPlugin(LibraryPlugin, ManagerPlugin):
    id = "pythia.library.egs"
    display_name = "Epic Games Store"
    version = "1.0.0"
    author = "pythia"
    compatible_sources = ["egs"]

    def _config_dir(self) -> Path:
        return self.data_dir() / "legendary"

    def _ensure_legendary(self) -> Path | None:
        """Download (once, cached in self.data_dir()) legendary's own real
        prebuilt binary for this exact machine's OS+architecture. None if no
        build exists here (arm64) or the download failed -- callers already
        treat None the same as "not connected/not available."."""
        url = _LEGENDARY_RELEASE.get((platform.system(), _normalized_arch()))
        if url is None:
            return None
        target = self.data_dir() / os.path.basename(url)
        if target.is_file():
            return target
        try:
            temp_path = target.with_suffix(target.suffix + ".part")
            with urllib.request.urlopen(url, timeout=60) as resp, open(temp_path, "wb") as f:
                while chunk := resp.read(1024 * 256):
                    f.write(chunk)
            temp_path.rename(target)
            if os.name != "nt":
                target.chmod(target.stat().st_mode | 0o111)
        except (urllib.error.URLError, OSError):
            return None
        return target

    def _run(self, *args: str, timeout: int = 30) -> subprocess.CompletedProcess | None:
        """Run the downloaded legendary binary with `args`, downloading it first
        if needed. Returns None (never raises) if no binary is available for this
        machine's architecture, the download failed, or the process itself
        couldn't be started -- every caller already treats None the same as "not
        connected"."""
        binary = self._ensure_legendary()
        if binary is None:
            return None
        env = {**os.environ, "LEGENDARY_CONFIG_PATH": str(self._config_dir())}
        try:
            return subprocess.run(
                [str(binary), "-y", *args],
                capture_output=True,
                text=True,
                env=env,
                timeout=timeout,
            )
        except (OSError, subprocess.SubprocessError):
            return None

    def login_url(self) -> str:
        return (
            "https://www.epicgames.com/id/login?redirectUrl="
            "https%3A//www.epicgames.com/id/api/redirect%3F"
            "clientId%3D34a02cf8f4414e29b15921876da36f9a%26responseType%3Dcode"
        )

    def connect_from_redirect_json(self, pasted_json: str) -> bool:
        """Parse the authorizationCode out of the pasted JSON page content (Epic's
        redirect page renders raw JSON as its content, not a URL query param -- a
        real, different shape from GOG/Steam) and hand it to `legendary auth
        --code`."""
        try:
            content = json.loads(pasted_json)
        except json.JSONDecodeError:
            return False
        code = content.get("authorizationCode")
        if not code:
            return False
        result = self._run("auth", "--code", code)
        return result is not None and result.returncode == 0

    def is_connected(self) -> bool:
        # legendary's own session file existing is a cheap, real signal -- avoids
        # spawning a subprocess just to answer "connected or not."
        return (self._config_dir() / "user.json").is_file()

    def _manifest_for(self, path: Path) -> dict | None:
        if not _MANIFESTS_DIR.is_dir():
            return None
        resolved = str(path.resolve())
        for item_path in _MANIFESTS_DIR.glob("*.item"):
            try:
                manifest = json.loads(item_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            install_location = manifest.get("InstallLocation")
            if install_location and str(Path(install_location).resolve()) == resolved:
                return manifest
        return None

    def is_root(self, path: Path) -> bool:
        return self._manifest_for(path) is not None

    def match(self, path: Path):
        manifest = self._manifest_for(path)
        if manifest is None:
            return None
        app_name = manifest.get("AppName") or manifest.get("MainGameAppName")
        return {
            "kind": "egs",
            "name": manifest.get("DisplayName"),
            "version_label": None,
            "platforms": ["windows"],
            "external_id": None,  # AppName is a slug/string, not a numeric ID
            "extra": {"egs_app_name": app_name} if app_name else {},
        }

    def list_owned(self):
        if not self.is_connected():
            return None
        if (platform.system(), _normalized_arch()) not in _LEGENDARY_RELEASE:
            return None

        result = self._run("list", "--json", "--third-party", timeout=60)
        if result is None or result.returncode != 0:
            return []

        try:
            games = json.loads(result.stdout)
        except json.JSONDecodeError:
            return []

        results = []
        for game in games:
            app_name = game.get("app_name")
            if not app_name:
                continue
            results.append(
                {
                    "kind": "egs",
                    "name": game.get("app_title") or app_name,
                    "version_label": None,
                    "platforms": [],
                    "external_id": None,
                    "extra": {"egs_app_name": app_name},
                }
            )
        return results

    # ---- Manager: hand-off to Epic's own client (merged 2026-08-03, see
    # steam.py's module docstring for why) -- real, documented URI protocol
    # (`com.epicgames.launcher://apps/<AppName>?action=launch&silent=true`,
    # confirmed against Epic's own developer docs, dev.epicgames.com/docs/
    # epic-games-store/protocol-activation -- not guessed). `AppName` is the
    # same identifier match()/list_owned() above already put in
    # extra["egs_app_name"] -- no separate lookup needed.
    def is_available(self, ctx) -> bool:
        """Same honest "unknown" as Steam's manager capability -- no reliable
        cross-platform "is the Epic client installed" check built yet."""
        return False

    def open(self, detection: dict, ctx) -> bool:
        """No-op (returns False) if `detection` has no Epic AppName to hand off to."""
        app_name = (detection.get("extra") or {}).get("egs_app_name")
        if not app_name:
            return False

        query = urllib.parse.urlencode({"action": "launch", "silent": "true"})
        uri = f"com.epicgames.launcher://apps/{app_name}?{query}"
        try:
            if sys.platform == "win32":
                os.startfile(uri)
            elif sys.platform == "darwin":
                subprocess.Popen(["open", uri])
            else:
                subprocess.Popen(["xdg-open", uri])
        except OSError:
            return False
        return True


PLUGIN_CLASSES = [EgsPlugin]
